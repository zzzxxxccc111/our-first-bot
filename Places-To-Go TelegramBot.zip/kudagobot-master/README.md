# KudaGo Telegram Bot

## Getting Started

Install dependencies

```bash
pip install -r requirements.txt
```

Run bot

```bash
python main.py
```
